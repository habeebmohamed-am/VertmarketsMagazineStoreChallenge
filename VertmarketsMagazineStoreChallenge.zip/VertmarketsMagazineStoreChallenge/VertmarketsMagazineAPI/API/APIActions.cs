﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VertmarketsMagazineAPI.Models;
using VertmarketsMagazineAPI.Utilities;

namespace VertmarketsMagazineAPI.API
{
    public class APIActions
    {
        public string APIToken { get; set; }
        public APIActions(string Token)
        {
            APIToken = Token;
        }
        public List<Subscribers> GetSubscribersList()
        {
            Subscribers respSubscribers = new Subscribers();
            List<Subscribers> subscribers = new List<Subscribers>();
            do
            {
                APIEndPoints _endPoints = APIEndPoints.GetInstance();
                var client = new RestClient(String.Format(_endPoints.GetSubscribers, APIToken))
                {
                    Timeout = -1
                };
                var request = new RestRequest(Method.GET);
                IRestResponse response = client.Execute(request);
                respSubscribers = JsonConvert.DeserializeObject<Subscribers>(response.Content,
                        new JsonSerializerSettings
                        {
                            PreserveReferencesHandling = PreserveReferencesHandling.Objects
                        });

                if (!respSubscribers.success)
                {
                    APIToken = RefreshToken.GetToken();
                }
                else
                {
                    subscribers.Add(respSubscribers);
                }

            } while (!respSubscribers.success);
            return subscribers;
        }

        public Subscribers GetSubscribers()
        {
            Subscribers respSubscribers = new Subscribers();
            do
            {
                APIEndPoints _endPoints = APIEndPoints.GetInstance();
                var client = new RestClient(String.Format(_endPoints.GetSubscribers, APIToken))
                {
                    Timeout = -1
                };
                var request = new RestRequest(Method.GET);
                IRestResponse response = client.Execute(request);
                respSubscribers = JsonConvert.DeserializeObject<Subscribers>(response.Content,
                        new JsonSerializerSettings
                        {
                            PreserveReferencesHandling = PreserveReferencesHandling.Objects
                        });

                if (!respSubscribers.success)
                {
                    APIToken = RefreshToken.GetToken();
                }
            } while (!respSubscribers.success);
            return respSubscribers;
        }


        public async Task<Subscribers> GetSubscribersAsync()
        {
            Subscribers respSubscribers = new Subscribers();

            await Task.Run(() =>
            {
                do
                {
                    APIEndPoints _endPoints = APIEndPoints.GetInstance();
                    var client = new RestClient(String.Format(_endPoints.GetSubscribers, APIToken))
                    {
                        Timeout = -1
                    };
                    var request = new RestRequest(Method.GET);
                    IRestResponse response = client.Execute(request);
                    respSubscribers = JsonConvert.DeserializeObject<Subscribers>(response.Content,
                            new JsonSerializerSettings
                            {
                                PreserveReferencesHandling = PreserveReferencesHandling.Objects
                            });

                    if (!respSubscribers.success)
                    {
                        APIToken = RefreshToken.GetToken();
                    }
                } while (!respSubscribers.success);
            });

            
            return respSubscribers;
        }

        public Magazines GetMagazines(string CategoryName)
        {
            Magazines respMagazines = new Magazines();
            do
            {
                APIEndPoints _endPoints = APIEndPoints.GetInstance();
                var client = new RestClient(String.Format(_endPoints.GetMagazines, APIToken, CategoryName))
                {
                    Timeout = -1
                };
                var request = new RestRequest(Method.GET);
                IRestResponse response = client.Execute(request);
                respMagazines = JsonConvert.DeserializeObject<Magazines>(response.Content,
                        new JsonSerializerSettings
                        {
                            PreserveReferencesHandling = PreserveReferencesHandling.Objects
                        });
                if (!respMagazines.success)
                {
                    APIToken = RefreshToken.GetToken();
                }

            } while (!respMagazines.success);
            return respMagazines;
        }

        public async Task<Magazines> GetMagazinesAsync(string CategoryName)
        {
            Magazines respMagazines = new Magazines();
            await Task.Run(() =>
            {
                do
                {
                    APIEndPoints _endPoints = APIEndPoints.GetInstance();
                    var client = new RestClient(String.Format(_endPoints.GetMagazines, APIToken, CategoryName))
                    {
                        Timeout = -1
                    };
                    var request = new RestRequest(Method.GET);
                    IRestResponse response = client.Execute(request);
                    respMagazines = JsonConvert.DeserializeObject<Magazines>(response.Content,
                            new JsonSerializerSettings
                            {
                                PreserveReferencesHandling = PreserveReferencesHandling.Objects
                            });
                    if (!respMagazines.success)
                    {
                        APIToken = RefreshToken.GetToken();
                    }

                } while (!respMagazines.success);
            });
            return respMagazines;
        }

        public List<Categories> GetCategoriesList()
        {
            Categories respCategories = new Categories();
            List<Categories> categories = new List<Categories>();
            do
            {
                APIEndPoints _endPoints = APIEndPoints.GetInstance();
                var client = new RestClient(String.Format(_endPoints.GetCategories, APIToken))
                {
                    Timeout = -1
                };
                var request = new RestRequest(Method.GET);
                IRestResponse response = client.Execute(request);
                respCategories = JsonConvert.DeserializeObject<Categories>(response.Content,
                        new JsonSerializerSettings
                        {
                            PreserveReferencesHandling = PreserveReferencesHandling.Objects
                        });
                if (!respCategories.success)
                {
                    APIToken = RefreshToken.GetToken();
                }
                else
                {
                    categories.Add(respCategories);
                }

            } while (!respCategories.success);
            return categories;
        }

        public Categories GetCategories()
        {
            Categories respCategories = new Categories();
            do
            {
                APIEndPoints _endPoints = APIEndPoints.GetInstance();
                var client = new RestClient(String.Format(_endPoints.GetCategories, APIToken))
                {
                    Timeout = -1
                };
                var request = new RestRequest(Method.GET);
                IRestResponse response = client.Execute(request);
                respCategories = JsonConvert.DeserializeObject<Categories>(response.Content,
                        new JsonSerializerSettings
                        {
                            PreserveReferencesHandling = PreserveReferencesHandling.Objects
                        });
                if (!respCategories.success)
                {
                    APIToken = RefreshToken.GetToken();
                }
               

            } while (!respCategories.success);
            return respCategories;
        }

        public async Task<Categories> GetCategoriesAsync()
        {
            Categories respCategories = new Categories();

            await Task.Run(() =>
            {
                do
                {
                    APIEndPoints _endPoints = APIEndPoints.GetInstance();
                    var client = new RestClient(String.Format(_endPoints.GetCategories, APIToken))
                    {
                        Timeout = -1
                    };
                    var request = new RestRequest(Method.GET);
                    IRestResponse response = client.Execute(request);
                    respCategories = JsonConvert.DeserializeObject<Categories>(response.Content,
                            new JsonSerializerSettings
                            {
                                PreserveReferencesHandling = PreserveReferencesHandling.Objects
                            });
                    if (!respCategories.success)
                    {
                        APIToken = RefreshToken.GetToken();
                    }


                } while (!respCategories.success);
                
            });

            return respCategories;

        }


        public Answer PostAnswer(AnswerRequest answerRequest)
        {
            Answer respAnswer = new Answer();
            string postData = string.Empty;
            do
            {
                postData = JsonConvert.SerializeObject(answerRequest, new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore });
                APIEndPoints _endPoints = APIEndPoints.GetInstance();
                var client = new RestClient(String.Format(_endPoints.PostAnswer, APIToken))
                {
                    Timeout = -1
                };
                var request = new RestRequest(Method.POST);
                request.AddHeader("Content-Type", "application/json");
                request.AddParameter("application/json", postData, ParameterType.RequestBody);
                IRestResponse response = client.Execute(request);
                respAnswer = JsonConvert.DeserializeObject<Answer>(response.Content,
                        new JsonSerializerSettings
                        {
                            PreserveReferencesHandling = PreserveReferencesHandling.Objects
                        });
                if (!respAnswer.success)
                {
                    APIToken = RefreshToken.GetToken();
                }


            } while (!respAnswer.success);
            return respAnswer;
        }
    }
}
