﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VertmarketsMagazineAPI.Contracts;
using VertmarketsMagazineAPI.Models;
using VertmarketsMagazineAPI.Utilities;


namespace VertmarketsMagazineAPI.API
{
    public class GetToken : IGenerateToken
    {

        public Token GenerateToken()
        {
            Token respToken = new Token();
            APIEndPoints _endPoints = APIEndPoints.GetInstance();
            var client = new RestClient(_endPoints.GenerateToken)
            {
                Timeout = -1
            };
            var request = new RestRequest(Method.GET);
            IRestResponse response = client.Execute(request);
            respToken = JsonConvert.DeserializeObject<Token>(response.Content,
                    new JsonSerializerSettings
                    {
                        PreserveReferencesHandling = PreserveReferencesHandling.Objects
                    });
            return respToken;
        }
    }
}
