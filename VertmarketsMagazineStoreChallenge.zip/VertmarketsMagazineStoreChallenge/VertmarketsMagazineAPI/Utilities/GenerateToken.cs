﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VertmarketsMagazineAPI.API;
using VertmarketsMagazineAPI.Models;

namespace VertmarketsMagazineAPI.Utilities
{
    public class RefreshToken
    {
        public static string GetToken()
        {
            GetToken _token = new GetToken();
            Token token = _token.GenerateToken();
            return token.token;
        }
    }
}
