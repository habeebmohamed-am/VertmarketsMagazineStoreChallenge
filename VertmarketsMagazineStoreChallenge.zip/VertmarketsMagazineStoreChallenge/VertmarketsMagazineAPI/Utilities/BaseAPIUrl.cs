﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
namespace VertmarketsMagazineAPI.Utilities
{
    public sealed class APIEndPoints
    {
        private readonly string BaseAPI;
        public readonly string GenerateToken;
        public readonly string GetSubscribers;
        public readonly string GetMagazines;
        public readonly string GetCategories;
        public readonly string PostAnswer;

        private static readonly Lazy<APIEndPoints> instance = new Lazy<APIEndPoints>(() => new APIEndPoints());
        private APIEndPoints()
        {
            BaseAPI = ConfigurationManager.AppSettings["BaseEndPoint"];
            GenerateToken = BaseAPI + ConfigurationManager.AppSettings["GenerateToken"];
            GetSubscribers = BaseAPI + ConfigurationManager.AppSettings["GetSubscribers"];
            GetMagazines = BaseAPI + ConfigurationManager.AppSettings["GetMagazines"];
            GetCategories = BaseAPI + ConfigurationManager.AppSettings["GetCategories"];
            PostAnswer = BaseAPI + ConfigurationManager.AppSettings["PostAnswer"];
        }

        public static APIEndPoints GetInstance()
        {
            return instance.Value;
        }
    }
}
