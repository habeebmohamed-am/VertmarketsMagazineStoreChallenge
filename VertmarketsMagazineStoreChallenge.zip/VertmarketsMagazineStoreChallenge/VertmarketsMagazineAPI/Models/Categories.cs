﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertmarketsMagazineAPI.Models
{
    public class Categories
    {
        public List<string> data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
    }
}
