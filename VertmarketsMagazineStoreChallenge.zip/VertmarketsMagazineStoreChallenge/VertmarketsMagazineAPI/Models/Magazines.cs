﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VertmarketsMagazineAPI.Models
{
    public class Magazines
    {
        public List<CategoryDetail> data { get; set; }
        public bool success { get; set; }
        public string token { get; set; }
    }

    public class CategoryDetail
    {
        public int id { get; set; }
        public string name { get; set; }
        public string category { get; set; }
    }

}
