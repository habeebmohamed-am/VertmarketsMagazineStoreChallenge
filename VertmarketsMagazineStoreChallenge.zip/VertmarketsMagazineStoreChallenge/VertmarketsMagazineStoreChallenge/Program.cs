﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using VertmarketsMagazineAPI;
using VertmarketsMagazineAPI.API;
using VertmarketsMagazineAPI.Models;
using VertmarketsMagazineAPI.Utilities;

namespace VertmarketsMagazineStoreChallenge
{
    class Program
    {
        static void Main(string[] args)
        {

            Program program = new Program();
            //program.ProcessRequest();
            program.ProcessRequestAsync().GetAwaiter().GetResult();

        }

        void ProcessRequest()
        {
            Console.WriteLine("Application Started ==> " + DateTime.Now);
            List<Magazines> magazines = new List<Magazines>();
            List<string> subsciberIDs = new List<string>();
            Subscribers subscribers = null;
            Categories categories = null;
            AnswerRequest answerRequest = new AnswerRequest();

            APIActions _details = new APIActions(RefreshToken.GetToken());
            categories = _details.GetCategories();
            foreach (string category in categories.data)
            {
                magazines.Add(_details.GetMagazines(category));
            }
            subscribers = _details.GetSubscribers();

            List<string> categoriesList = categories.data.ToList();
            foreach (var x in subscribers.data)
            {
                List<int> MagazineId = MagazineId = x.magazineIds;
                List<string> SubscriberCategories = magazines.SelectMany(z => z.data).Where(y => MagazineId.Contains(y.id)).Select(s => s.category).Distinct().ToList();
                bool isEqual = Enumerable.SequenceEqual(categoriesList.OrderBy(e => e), SubscriberCategories.OrderBy(e => e));
                if (isEqual)
                    subsciberIDs.Add(x.id);
            }

            answerRequest.subscribers = subsciberIDs;

            Answer answerResponse = null;
            answerResponse = _details.PostAnswer(answerRequest);
            Console.WriteLine(String.Format("Submit Answer Response ==> {0}. Is the answer correct ==> {1} , total time ==> {2}", answerResponse.success, answerResponse.data.answerCorrect, answerResponse.data.totalTime));

            Console.WriteLine("Application Ended ==> " + DateTime.Now);
            Console.WriteLine("Press any key to close the application.");
            Console.ReadLine();
        }

        async Task ProcessRequestAsync()
        {
            Console.WriteLine("Application Started ==> " + DateTime.Now);
            List<Magazines> magazines = new List<Magazines>();
            List<string> subsciberIDs = new List<string>();
            AnswerRequest answerRequest = new AnswerRequest();

            APIActions _details = new APIActions(RefreshToken.GetToken());
            var subscribersTask = _details.GetSubscribersAsync();
            var categoriesTask = _details.GetCategoriesAsync();
            var categories = await categoriesTask;


            List<Task<Magazines>> Magazinetasks = new List<Task<Magazines>>();

            foreach (string category in categories.data)
            {
                Magazinetasks.Add(_details.GetMagazinesAsync(category));
            }

            var subscribers = await subscribersTask;

            var magazinetaskCompleted = await Task.WhenAll(Magazinetasks);
            magazines = magazinetaskCompleted.ToList();
            List<string> categoriesList = categories.data.ToList();
            foreach (var x in subscribers.data)
            {
                List<int> MagazineId = MagazineId = x.magazineIds;
                List<string> SubscriberCategories = magazines.SelectMany(z => z.data).Where(y => MagazineId.Contains(y.id)).Select(s => s.category).Distinct().ToList();
                bool isEqual = Enumerable.SequenceEqual(categoriesList.OrderBy(e => e), SubscriberCategories.OrderBy(e => e));
                if (isEqual)
                    subsciberIDs.Add(x.id);
            }
            answerRequest.subscribers = subsciberIDs;
            Answer answerResponse = null;
            answerResponse = _details.PostAnswer(answerRequest);
            Console.WriteLine(String.Format("Submit Answer Response ==> {0}. Is the answer correct ==> {1} , total time ==> {2}", answerResponse.success, answerResponse.data.answerCorrect, answerResponse.data.totalTime));
            Console.WriteLine("Application Ended ==> " + DateTime.Now);
            Console.WriteLine("Press any key to close the application.");
            Console.ReadLine();
        }
    }
}
